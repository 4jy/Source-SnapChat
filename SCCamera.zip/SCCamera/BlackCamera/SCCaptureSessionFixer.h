//
//  SCCaptureSessionFixer.h
//  Snapchat
//
//  Created by Derek Wang on 05/12/2017.
//

#import "SCBlackCameraNoOutputDetector.h"

#import <Foundation/Foundation.h>

@interface SCCaptureSessionFixer : NSObject <SCBlackCameraDetectorDelegate>

@end
