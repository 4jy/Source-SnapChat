//
//  SCManagedPhotoCapturer.h
//  Snapchat
//
//  Created by Chao Pang on 10/5/16.
//  Copyright © 2016 Snapchat, Inc. All rights reserved.
//

#import "SCManagedStillImageCapturer.h"

@interface SCManagedPhotoCapturer : SCManagedStillImageCapturer

@end
