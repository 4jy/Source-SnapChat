//
//  SCManagedVideoStreamReporter.h
//  Snapchat
//
//  Created by Liu Liu on 5/16/15.
//  Copyright (c) 2015 Snapchat, Inc. All rights reserved.
//

#import <SCCameraFoundation/SCManagedVideoDataSourceListener.h>

#import <Foundation/Foundation.h>

@interface SCManagedVideoStreamReporter : NSObject <SCManagedVideoDataSourceListener>

@end
