//
//  SCManagedCapturePreviewViewDebugView.h
//  Snapchat
//
//  Created by Jiyang Zhu on 1/19/18.
//  Copyright © 2018 Snapchat, Inc. All rights reserved.
//

#import <AVFoundation/AVFoundation.h>
#import <UIKit/UIKit.h>

@interface SCManagedCapturePreviewViewDebugView : UIView

@end
